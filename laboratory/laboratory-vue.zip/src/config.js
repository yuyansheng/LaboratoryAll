export const API_PATH = '/api';
